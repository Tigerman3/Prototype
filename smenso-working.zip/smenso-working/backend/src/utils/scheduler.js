function buildGraph(tasks, deps) {
  const map = {};
  tasks.forEach(t => { map[t.id] = { ...t, predecessors: [], successors: [], start: 0, end: 0, slack: 0, critical: false }; });
  deps.forEach(d => { if (map[d.fromId] && map[d.toId]) { map[d.fromId].successors.push(map[d.toId]); map[d.toId].predecessors.push(map[d.fromId]); } });
  return map;
}
function topo(graph) {
  const visited = new Set(); const visiting = new Set(); const result = [];
  function visit(t) {
    if (visiting.has(t.id)) throw new Error('Zyklische Abhängigkeit erkannt');
    if (visited.has(t.id)) return;
    visiting.add(t.id); t.predecessors.forEach(visit); visiting.delete(t.id); visited.add(t.id); result.push(t);
  }
  Object.values(graph).forEach(visit); return result;
}
function scheduleTasks(tasks, deps) {
  const graph = buildGraph(tasks, deps); const ordered = topo(graph);
  ordered.forEach(t => { t.start = t.predecessors.reduce((m,p)=>Math.max(m, p.end), 0); t.end = t.start + t.duration; });
  const projectEnd = Math.max(...ordered.map(t=>t.end), 0);
  [...ordered].reverse().forEach(t => { const lf = t.successors.length ? Math.min(...t.successors.map(s=>s.start)) : projectEnd; const ls = lf - t.duration; t.slack = ls - t.start; t.critical = t.slack === 0; });
  return ordered.map(t => ({ id: t.id, start: t.start, end: t.end, slack: t.slack, critical: t.critical }));
}
module.exports = scheduleTasks;
